# ta_OT_ULB

Tamil OT conversion to resource container format. Stage 3 files from https://git.door43.org/BCS-BIBLE/TAMIL-ULB-OT.BCS.