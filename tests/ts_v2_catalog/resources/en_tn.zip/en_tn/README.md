# translationNotes - English
Source for English translationNotes.

See the [LICENSE](https://git.door43.org/Door43/tn-en/src/master/LICENSE.md) file for licensing information.
