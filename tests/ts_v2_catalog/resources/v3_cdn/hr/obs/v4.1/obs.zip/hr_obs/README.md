# hr_obs

Resource container for Croatian open Bible stories. Content from https://git.door43.org/toddlprice/hr_obs_text_obs.